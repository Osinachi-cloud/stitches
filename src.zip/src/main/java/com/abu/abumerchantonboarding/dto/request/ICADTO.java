package com.abu.abumerchantonboarding.dto.request;

import com.abu.abumerchantonboarding.model.Country;
import com.abu.abumerchantonboarding.model.Merchant;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ICADTO {
    private String code;
    private String name;
//    private List<Merchant> merchants;
//    private Country country;
}
