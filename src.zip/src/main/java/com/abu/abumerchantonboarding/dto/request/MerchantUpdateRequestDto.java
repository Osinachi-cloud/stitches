package com.abu.abumerchantonboarding.dto.request;

import com.abu.abumerchantonboarding.enums.FileDeliveryStatus;
import com.abu.abumerchantonboarding.enums.RequestType;
import com.abu.abumerchantonboarding.enums.Status;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class MerchantUpdateRequestDto{
    private String acquirerIdentifier;
    private String merchantID;
    private RequestType requestType;
    private String cardAcceptorBusinessCode;
    private String email;
    private String mobile;
    private String countryCode;
    private Long icaId;
    private Status status;
    private FileDeliveryStatus fileDeliveryStatus;

}
