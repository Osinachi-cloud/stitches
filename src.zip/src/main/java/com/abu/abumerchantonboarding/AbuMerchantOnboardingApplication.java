package com.abu.abumerchantonboarding;


import com.kelmorgan.encrypterservice.service.Encrypter;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "Library APIS", version = "1.0", description = "Library Management APis."))
@EnableMethodSecurity(prePostEnabled = true)
@EnableScheduling
public class AbuMerchantOnboardingApplication {


    public static void main(String[] args) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        boolean valid = passwordEncoder.matches("1234","$2a$10$SJzBvyY10bINxjkzMZDVVu8BsyB6/hbPfxB09BJziUCHzMt9nj0HO");
        System.out.println("Password is valid => "+valid);
//        System.out.println(Encrypter.decryptSecret("automaticbillingupdater$123"));
        SpringApplication.run(AbuMerchantOnboardingApplication.class, args);
    }

}
