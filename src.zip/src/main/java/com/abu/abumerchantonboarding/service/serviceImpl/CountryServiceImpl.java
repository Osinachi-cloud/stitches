package com.abu.abumerchantonboarding.service.serviceImpl;

import com.abu.abumerchantonboarding.dto.request.CountryDTO;
import com.abu.abumerchantonboarding.exceptions.ApiRequestException;
import com.abu.abumerchantonboarding.model.Country;
import com.abu.abumerchantonboarding.repository.CountryRepository;
import com.abu.abumerchantonboarding.service.CountryService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;

    public CountryServiceImpl(CountryRepository countryRepository){
        this.countryRepository = countryRepository;
    }

    @Override
    public CountryDTO addCountry(CountryDTO countryDTO) {
        Country country = new Country();
        BeanUtils.copyProperties(countryDTO, country);
        Country savedCountry = countryRepository.save(country);
        CountryDTO countryDTOResponse = new CountryDTO();
        BeanUtils.copyProperties(savedCountry, countryDTOResponse);
        return countryDTOResponse;
    }

    @Override
    public Optional<List<Country>> findAllCountries() {
        Optional<List<Country>> countries = Optional.of(countryRepository.findAll());
        if(!countries.isPresent()){
            throw new ApiRequestException("Countries not found");
        }
        return countries;
    }

    @Override
    public Optional<Country> findCountryByCode(String code) {
        Optional<Country> country = countryRepository.findCountryByCode(code);
        if(!country.isPresent()){
            throw new ApiRequestException("Country not found");
        }
        return country;
    }

    @Override
    public void deleteCountryById(Long id) {
        countryRepository.deleteCountryById(id);
    }
}
