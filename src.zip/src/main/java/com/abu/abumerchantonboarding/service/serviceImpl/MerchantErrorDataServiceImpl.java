package com.abu.abumerchantonboarding.service.serviceImpl;

import com.abu.abumerchantonboarding.service.MerchantErrorDataService;
import org.springframework.stereotype.Service;

@Service
public class MerchantErrorDataServiceImpl implements MerchantErrorDataService {
    @Override
    public void uploadFile() {
    }
}
