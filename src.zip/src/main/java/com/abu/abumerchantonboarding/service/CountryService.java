package com.abu.abumerchantonboarding.service;

import com.abu.abumerchantonboarding.dto.request.CountryDTO;
import com.abu.abumerchantonboarding.model.Country;

import java.util.List;
import java.util.Optional;

public interface CountryService {

    CountryDTO addCountry(CountryDTO countryDTO);
    Optional<List<Country>> findAllCountries();

    Optional<Country> findCountryByCode(String code);

    void deleteCountryById(Long id);
}
