package com.abu.abumerchantonboarding.service;

import com.abu.abumerchantonboarding.dto.request.AuthenticationRequest;
import com.abu.abumerchantonboarding.dto.request.RegisterRequest;
import com.abu.abumerchantonboarding.dto.request.UserRequest;
import com.abu.abumerchantonboarding.dto.response.AuthenticationResponse;
import com.abu.abumerchantonboarding.dto.response.RegistrationResponse;
import com.abu.abumerchantonboarding.dto.response.UserResponse;
import com.abu.abumerchantonboarding.model.AppUser;
import com.abu.abumerchantonboarding.model.Merchant;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Optional;

public interface UserService {

    AuthenticationResponse authenticate(AuthenticationRequest request);
    RegistrationResponse register(RegisterRequest request);
    Page<AppUser> getUsers(String name, int page, int size);
    Optional<UserResponse> findAppUserByEmail(String email);
    UserResponse updateUser(String email, UserRequest userRequest);

}
