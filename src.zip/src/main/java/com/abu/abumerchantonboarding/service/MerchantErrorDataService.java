package com.abu.abumerchantonboarding.service;



public interface MerchantErrorDataService {

    void uploadFile();
}
