package com.abu.abumerchantonboarding.service;

import com.abu.abumerchantonboarding.dto.request.ICADTO;
import com.abu.abumerchantonboarding.model.ICA;

import java.util.List;
import java.util.Optional;

public interface ICAService {
    List<ICADTO> addICA(List<ICADTO> icaDTO, String countryCode);
//    Optional<List<ICA>> findICAByCountry_Code(String countryCode);
    void deleteICAById(Long id);
}
