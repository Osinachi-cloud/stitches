package com.abu.abumerchantonboarding.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class  Country {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String code;

//    @ToString.Exclude
//    @OneToMany(fetch = FetchType.EAGER)
////    @JoinColumn(name = "ica_id")
//    private List<Merchant> merchants;

//    @ToString.Exclude
    @OneToMany(fetch = FetchType.EAGER)
//    @JoinColumn(name = "ica_id")
    private List<ICA> ica;

}
