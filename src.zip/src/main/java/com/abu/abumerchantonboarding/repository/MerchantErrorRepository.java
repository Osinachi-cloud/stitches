package com.abu.abumerchantonboarding.repository;

import com.abu.abumerchantonboarding.model.MerchantErrorObj;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantErrorRepository extends JpaRepository<MerchantErrorObj, Long> {

}
