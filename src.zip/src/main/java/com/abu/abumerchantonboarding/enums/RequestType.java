package com.abu.abumerchantonboarding.enums;

public enum RequestType {
    R,
    D
}
