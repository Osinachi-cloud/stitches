package com.abu.abumerchantonboarding.enums;

public enum FileDeliveryStatus {
    NOT_SENT,
    SENT
}
