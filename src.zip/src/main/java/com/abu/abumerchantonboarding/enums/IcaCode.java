package com.abu.abumerchantonboarding.enums;

public enum IcaCode {
    ICA1,
    ICA2,
    ICA3,
    ICA4,
    ICA5
}
