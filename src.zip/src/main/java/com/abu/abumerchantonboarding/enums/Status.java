package com.abu.abumerchantonboarding.enums;

public enum Status {
    Approved,
    Rejected,
    Pending,
    Deleted
}
